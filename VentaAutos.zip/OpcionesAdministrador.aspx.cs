﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Autos
{
    public partial class OpcionesAdministrador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonConsultarPrecioAuto_Click(object sender, EventArgs e)
        {
            Response.Redirect("ConsultarPrecioAutomovil.aspx");
        }

        protected void ButtonConsultarPrecioExtra_Click(object sender, EventArgs e)
        {
            Response.Redirect("ConsultarPrecioExtra.aspx");
        }

        protected void ButtonVerAutomoviles_Click(object sender, EventArgs e)
        {
            Response.Redirect("VerAutomoviles.aspx");
        }

        protected void ButtonVerCaracteristicas_Click(object sender, EventArgs e)
        {
            Response.Redirect("VerCaracteristicas.aspx");
        }

        protected void ButtonVerAutosMasVendidosGlobal_Click(object sender, EventArgs e)
        {
            Response.Redirect("VerAutosMasVendidosGlobal.aspx");
        }

        protected void ButtonVerAutosMasVendidosSucursal_Click(object sender, EventArgs e)
        {
            Response.Redirect("VerAutosMasVendidosSucursal.aspx");
        }

        protected void ButtonVerAutosSinSalidaGloabl_Click(object sender, EventArgs e)
        {
            Response.Redirect("VerAutosSinSalidaGlobal.aspx");
        }
    }
}