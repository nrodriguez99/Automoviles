﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Autos
{
    public partial class ConsultarPrecioAutomovil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAceptar_Click(object sender, EventArgs e)
        {
         
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            guardarDatos(Int32.Parse(TextBox2.Text), System.Convert.ToDecimal(TextBox3.Text));
        }
        protected void guardarDatos(int idAutomovil, decimal precioBase)
        {
            SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-SV37236\NATALIASQL;Initial Catalog=Fabrica;Integrated Security=True");
            SqlCommand comando = conexion.CreateCommand();
            comando.CommandText = "spActualizarPrecioAutomovil";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idAutomovil", idAutomovil);
            comando.Parameters.AddWithValue("@precioBase", precioBase);
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                LabelAcualizado.Visible = true;
            }
            catch (Exception e)
            {
                LabelError.Visible = true;

            }
        }

    }
}