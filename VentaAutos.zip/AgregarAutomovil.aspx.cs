﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Autos
{
    public partial class AgregarAutomovil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAceptar_Click(object sender, EventArgs e)
        {
            guardarDatos(Int32.Parse(TextTipoAutomovil.Text), Int32.Parse(TextTipoCombustible.Text), TextPlaca.Text, System.Convert.ToDecimal(TextPrecioBase.Text),
                Convert.ToBoolean(TextConsignacion.Text), Int32.Parse(TextAnno.Text), Int32.Parse(TextCaracteristica.Text), Int32.Parse(TextSucursal.Text));
        }

        protected void guardarDatos(int idTipoAutomovil, int idTipoCombustible, string placa, decimal precioBase, bool consignacion, int anno, int idCaracteristica, int idSucursal )
        {
            SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-SV37236\NATALIASQL;Initial Catalog=Fabrica;Integrated Security=True");
            SqlCommand comando = conexion.CreateCommand();
            comando.CommandText = "spAgregarAutomovil";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idTipoAutomovil", idTipoAutomovil);
            comando.Parameters.AddWithValue("@idTipoCombustible", idTipoCombustible);
            comando.Parameters.AddWithValue("@placa", placa);
            comando.Parameters.AddWithValue("@precioBase", precioBase);
            comando.Parameters.AddWithValue("@consignacion", SqlDbType.Bit).Value = consignacion;
            comando.Parameters.AddWithValue("@anno", anno);
            comando.Parameters.AddWithValue("@idCaracteristicaS", idCaracteristica);
            comando.Parameters.AddWithValue("@idSucursal", idSucursal);
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                LabelAcualizado.Visible = true;
            }
            catch (Exception e)
            {
                LabelError.Visible = true;

            }
        }
    }
}