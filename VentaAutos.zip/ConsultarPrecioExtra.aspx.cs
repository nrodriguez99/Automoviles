﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Autos
{
    public partial class ConsultarPrecioExtra : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAceptar_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            guardarDatos(Int32.Parse(TextBox2.Text), System.Convert.ToDecimal(TextBox3.Text));
        }
        protected void guardarDatos(int idExtra, decimal precio)
        {
            SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-SV37236\NATALIASQL;Initial Catalog=Fabrica;Integrated Security=True");
            SqlCommand comando = conexion.CreateCommand();
            comando.CommandText = "spActualizarPrecioExtra";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idExtra", idExtra);
            comando.Parameters.AddWithValue("@precio", precio);
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                LabelActualizado.Visible = true;
            }
            catch (Exception e)
            {
                LabelError.Visible = true;

            }
        }
    }
}